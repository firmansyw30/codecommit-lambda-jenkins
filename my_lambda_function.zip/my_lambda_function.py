import os
import json
from request_layer.requests import Session
from request_layer.requests.auth import HTTPBasicAuth

# Environment variables
USERNAME = os.environ['USERNAME']
JENKINS_URL = os.environ['JENKINS_URL']
API_TOKEN = os.environ['API_TOKEN']

def lambda_handler(event, context):
    try:
        print(f"INCOMING EVENT: {json.dumps(event)}") # Log event data
        
        # Parse event data to get job_name and token_name
        job_name, token_name = parse_event_data(event)
        
        if not job_name or not token_name:
            print("❌ ERROR: job_name or token_name could not be determined from the event.")
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Missing job_name or token_name in event'})
            }
        
        print(f"✅ Job determined: {job_name}, Token: {token_name}")
        url = f"http://{JENKINS_URL}/job/{job_name}/build?token={token_name}&cause=Triggered+by+Lambda"
        
        print(f"🔧 Sending POST to Jenkins: {url}")
        print(f"👤 Using auth: {USERNAME}")
        
        response = requests.post(url, auth=HTTPBasicAuth(USERNAME, API_TOKEN))

        print(f"🧪 Response code: {response.status_code}")
        print(f"🧾 Response body: {response.text}")

        if response.status_code == 201:
            print("✅ Build triggered successfully!")
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'message': 'Build triggered successfully',
                    'job_name': job_name,
                    'status_code': response.status_code
                })
            }
        else:
            print(f"❌ Error triggering build: {response.status_code} - {response.text}")
            return {
                'statusCode': response.status_code,
                'body': json.dumps({
                    'error': 'Failed to trigger build',
                    'job_name': job_name,
                    'status_code': response.status_code,
                    'response_text': response.text
                })
            }

    except Exception as err:
        print(f"⚠️ Exception occurred: {err}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(err)})
        }

def parse_direct_event(event):
    """Handle direct events with job_name and token_name."""
    if 'job_name' in event and 'token_name' in event:
        return event['job_name'], event['token_name']
    return None, None

def parse_codecommit_detail(event):
    """Handle CodeCommit detail events."""
    if 'detail' in event and 'repositoryName' in event.get('detail', {}):
        repo_name = event['detail']['repositoryName']
        reference = event['detail'].get('reference', '')
        return process_codecommit_reference(repo_name, reference)
    return None, None

def parse_records_event(event):
    """Handle events with Records."""
    if 'Records' not in event or not event['Records']:
        return None, None
    
    record = event['Records'][0]
    if 's3' in record:
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']
        print(f"S3 event detected for bucket: '{bucket}' and key: '{key}'")
        return None, None
    
    if 'codecommit' in record and record.get('eventSource') == 'aws:codecommit':
        repo_name = record['eventSourceARN'].split(':')[-1]
        reference = record['codecommit']['references'][0].get('ref', '')
        return process_codecommit_reference(repo_name, reference)
    
    return None, None

def parse_api_gateway_event(event):
    """Handle API Gateway events."""
    if 'body' in event:
        try:
            body = json.loads(event['body'])
            if 'job_name' in body and 'token_name' in body:
                return body['job_name'], body['token_name']
        except (json.JSONDecodeError, TypeError):
            pass
    return None, None

def process_codecommit_reference(repo_name, reference):
    """Process CodeCommit reference to extract branch name."""
    if not reference.startswith('refs/heads/'):
        return None, None
        
    branch_name = reference.split('refs/heads/', 1)[1]
    print(f"CodeCommit event detected for repo: '{repo_name}' and branch: '{branch_name}'")
    
    if repo_name and branch_name:
        return map_repo_to_job(repo_name, branch_name)
    return None, None

def parse_event_data(event):
    """
    Parse event data untuk mengekstrak job_name dan token_name.
    Mendukung berbagai sumber event (CodeCommit, S3, API Gateway, dll.)
    """
    job_name = os.environ.get('JOB_NAME')
    token_name = os.environ.get('TOKEN_NAME')
    
    for parser in [parse_direct_event, parse_codecommit_detail, 
                  parse_records_event, parse_api_gateway_event]:
        result = parser(event)
        if result != (None, None):
            return result
            
    return job_name, token_name

# Define constants for commonly used branch names
DEV_DEPLOYMENT = 'dev/deployment'
BETA_DEPLOYMENT = 'beta/deployment'

def map_repo_to_job(repo_name, branch_name):
    """
    Map repository CodeCommit and branch names to Jenkins job names and tokens.
    Returns a tuple of (job_name, token_name) or (None, None) if no mapping is found.
    """
    print(f"Mapping repo '{repo_name}' and branch '{branch_name}' to a Jenkins job.")
    
    mapping = {
        'geoserver': {
            DEV_DEPLOYMENT: ('dev-geoserver-nodejs-pipeline', 'aws-lambda-trigger-nodejs'),
            BETA_DEPLOYMENT: ('beta-geoserver-nodejs-pipeline', 'aws-lambda-trigger-nodejs')
        },
        'server_mapid_bun': {
            DEV_DEPLOYMENT: ('dev-geoserver-bunjs-pipeline', 'aws-lambda-trigger-bunjs'),
            BETA_DEPLOYMENT: ('beta-geoserver-bunjs-pipeline', 'aws-lambda-trigger-bunjs'),
            'docker/experiment':('tes-dev-geoserver-bunjs-pipeline', 'aws-lambda-trigger-bunjs')
        },
        'be_mapid_refactoring': {
            DEV_DEPLOYMENT: ('dev-geoserver-nodejs-refactoring-pipeline', 'aws-lambda-trigger-nodejs-refactoring'),
            BETA_DEPLOYMENT: ('beta-geoserver-nodejs-refactoring-pipeline', 'aws-lambda-trigger-nodejs-refactoring-beta')
        },
        # --- TAMBAHKAN ENTRI UNTUK REPO PENGUJIAN ANDA DI SINI ---
        'mapid_landing_page_2025': {
            'staging-deploy': ('mapid-landing-page-job', 'mapid-landing-page-trigger')
        },
        'formmapid': { # Frontend formmapid to s3
            'master': ('test-formmapid-job', 'aws-lambda-trigger-formmapid')
        },
        'publications':{ # Frontend publication to s3
            'master': ('test-publication-mapid-job', 'aws-lambda-trigger-publication-mapid')
        },
        'geomapid':{ # Frontend Geo to s3
            'master': ('test-geomapid-job', 'aws-lambda-trigger-geomapid')
        }
    }
    
    if repo_name in mapping and branch_name in mapping[repo_name]:
        job_info = mapping[repo_name][branch_name]
        print(f"Found mapping: {job_info}")
        return job_info
    
    print("No specific mapping found. Returning None.")
    # Return None if no specific mapping is found
    # For prevent accidental triggering of default jobs.
    return None, None
